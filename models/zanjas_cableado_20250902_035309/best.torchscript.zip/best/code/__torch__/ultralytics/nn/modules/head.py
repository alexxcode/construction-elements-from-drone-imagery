class Segment(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv2 : __torch__.torch.nn.modules.container.___torch_mangle_182.ModuleList
  cv3 : __torch__.torch.nn.modules.container.___torch_mangle_207.ModuleList
  dfl : __torch__.ultralytics.nn.modules.block.DFL
  proto : __torch__.ultralytics.nn.modules.block.Proto
  cv4 : __torch__.torch.nn.modules.container.___torch_mangle_242.ModuleList
  def forward(self: __torch__.ultralytics.nn.modules.head.Segment,
    argument_1: Tensor,
    argument_2: Tensor,
    argument_3: Tensor) -> Tuple[Tensor, Tensor]:
    dfl = self.dfl
    cv3 = self.cv3
    _2 = getattr(cv3, "2")
    cv2 = self.cv2
    _20 = getattr(cv2, "2")
    cv30 = self.cv3
    _1 = getattr(cv30, "1")
    cv20 = self.cv2
    _10 = getattr(cv20, "1")
    cv31 = self.cv3
    _0 = getattr(cv31, "0")
    cv21 = self.cv2
    _00 = getattr(cv21, "0")
    cv4 = self.cv4
    _21 = getattr(cv4, "2")
    cv40 = self.cv4
    _11 = getattr(cv40, "1")
    cv41 = self.cv4
    _01 = getattr(cv41, "0")
    cv42 = self.cv4
    _22 = getattr(cv42, "2")
    _12 = getattr(_22, "1")
    act = _12.act
    proto = self.proto
    _3 = (proto).forward(act, argument_1, )
    bs = ops.prim.NumToTensor(torch.size(_3, 0))
    _4 = int(bs)
    _5 = int(bs)
    _6 = int(bs)
    _7 = torch.view((_01).forward(act, argument_1, ), [_6, 32, -1])
    _8 = torch.view((_11).forward(act, argument_2, ), [_5, 32, -1])
    _9 = torch.view((_21).forward(argument_3, ), [_4, 32, -1])
    mc = torch.cat([_7, _8, _9], 2)
    _13 = [(_00).forward(act, argument_1, ), (_0).forward(act, argument_1, )]
    xi = torch.cat(_13, 1)
    _14 = [(_10).forward(act, argument_2, ), (_1).forward(act, argument_2, )]
    xi0 = torch.cat(_14, 1)
    _15 = [(_20).forward(act, argument_3, ), (_2).forward(act, argument_3, )]
    xi1 = torch.cat(_15, 1)
    _16 = ops.prim.NumToTensor(torch.size(xi, 0))
    _17 = int(_16)
    _18 = int(_16)
    _19 = [torch.view(xi, [int(_16), 81, -1]), torch.view(xi0, [_18, 81, -1]), torch.view(xi1, [_17, 81, -1])]
    _23 = torch.split_with_sizes(torch.cat(_19, 2), [64, 17], 1)
    x, cls, = _23
    _24 = (dfl).forward(x, )
    anchor_points = torch.unsqueeze(CONSTANTS.c0, 0)
    lt, rb, = torch.chunk(_24, 2, 1)
    x1y1 = torch.sub(anchor_points, lt)
    x2y2 = torch.add(anchor_points, rb)
    c_xy = torch.div(torch.add(x1y1, x2y2), CONSTANTS.c1)
    wh = torch.sub(x2y2, x1y1)
    dbox = torch.mul(torch.cat([c_xy, wh], 1), CONSTANTS.c2)
    x0 = torch.cat([dbox, torch.sigmoid(cls)], 1)
    return (torch.cat([x0, mc], 1), _3)
